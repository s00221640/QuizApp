﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace QuizApp
{
    public partial class MainWindow : Window
    {
        private List<Question> questions;

        public MainWindow()
        {
            InitializeComponent();
            questions = new List<Question>();

            //Adding sample questions
            AddSampleQuestions();
        }

        private void AddSampleQuestions()
        {
            //Sample questions for Geography
            questions.Add(new Question(1, "What is the capital of France?", new string[] { "London", "Paris", "Berlin", "Madrid" }, 1, "Geography", "images/geography.jpeg", null));
            questions.Add(new Question(2, "Which river is the longest in the world?", new string[] { "Yangtze", "Amazon", "Nile", "Shannon" }, 2, "Geography", "images/geography.jpeg", null));
            questions.Add(new Question(3, "In which country is the Great Barrier Reef located?", new string[] { "Australia", "Brazil", "Mexico", "India" }, 0, "Geography", "images/geography.jpeg", null));

            //Sample questions for Science
            questions.Add(new Question(4, "What is the chemical symbol for water?", new string[] { "O2", "CO2", "NaCl", "H2O" }, 3, "Science", "images/science.jpeg", null));
            questions.Add(new Question(5, "Which gas do plants use for photosynthesis?", new string[] { "Carbon dioxide", "Oxygen", "Nitrogen", "Hydrogen" }, 0, "Science", "images/science.jpeg", null));
            questions.Add(new Question(6, "What is the hardest natural substance on Earth?", new string[] { "Quarts", "Gold", "Iron", "Diamond" }, 3, "Science", "images/science.jpeg", null));

            //Sample questions for Literature
            questions.Add(new Question(7, "Who wrote 'Romeo and Juliet'?", new string[] { "William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain" }, 0, "Literature", "images/literature.jpeg", null));
            questions.Add(new Question(8, "Which novel features the character Sherlock Holmes?", new string[] { "The Hound of the Baskervilles", "Pride and Prejudice", "Moby-Dick", "War and Peace" }, 0, "Literature", "images/literature.jpeg", null));
            questions.Add(new Question(9, "Who is the author of '1984'?", new string[] { "George Orwell", "J.R.R. Tolkien", "H.G. Wells", "Aldous Huxley" }, 0, "Literature", "images/literature.jpeg", null));

            //Sample questions for Mathematics
            questions.Add(new Question(10, "What is the value of π (pi) to two decimal places?", new string[] { "3.14", "3.16", "3.12", "3.18" }, 0, "Mathematics", "images/mathematics.jpeg", null));
            questions.Add(new Question(11, "What is the square root of 144?", new string[] { "12", "10", "14", "16" }, 0, "Mathematics", "images/mathematics.jpeg", null));
            questions.Add(new Question(12, "Solve the equation: 2x + 5 = 15, x=(?)", new string[] { "5", "10", "7", "8" }, 1, "Mathematics", "images/mathematics.jpeg", null));

            //Sample questions for History
            questions.Add(new Question(13, "In which year did World War II end?", new string[] { "1918", "1939", "1945", "1941" }, 2, "History", "images/history.jpeg", null));
            questions.Add(new Question(14, "Who was the first president of the United States?", new string[] { "George Washington", "Thomas Jefferson", "John Adams", "Abraham Lincoln" }, 0, "History", "images/history.jpeg", null));
            questions.Add(new Question(15, "What year did the Titanic sink?", new string[] { "1908", "1912", "1910", "1915" }, 1, "History", "images/history.jpeg", null));
        }

        private void TakeQuiz_Click(object sender, RoutedEventArgs e)
        {
            //Create list to store selected questions
            List<Question> selectedQuestions = new List<Question>();

            //Select random questions based on the selected subjects
            if (chkGeography.IsChecked == true)
            {
                AddRandomQuestions(selectedQuestions, "Geography");
            }
            if (chkScience.IsChecked == true)
            {
                AddRandomQuestions(selectedQuestions, "Science");
            }
            if (chkLiterature.IsChecked == true)
            {
                AddRandomQuestions(selectedQuestions, "Literature");
            }
            if (chkMathematics.IsChecked == true)
            {
                AddRandomQuestions(selectedQuestions, "Mathematics");
            }
            if (chkHistory.IsChecked == true)
            {
                AddRandomQuestions(selectedQuestions, "History");
            }

            //Open quiz window, pass selected questions
            if (selectedQuestions.Count > 0)
            {
                var quizWindow = new QuizWindow(selectedQuestions);
                quizWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("No questions selected.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddRandomQuestions(List<Question> selectedQuestions, string subject)
        {
            Random rand = new Random();
            var filteredQuestions = questions.Where(q => q.Subject == subject).ToList();
            int count = filteredQuestions.Count;
            if (count > 0)
            {
                for (int i = 0; i < Math.Min(3, count); i++)
                {
                    int index = rand.Next(count);
                    selectedQuestions.Add(filteredQuestions[index]);
                    filteredQuestions.RemoveAt(index);
                    count--;
                }
            }
        }

        private void OpenQuiz_Click(object sender, RoutedEventArgs e)
        {
            // open a quiz from file
            var loadedQuestions = OpenQuizFromFile();
            if (loadedQuestions != null && loadedQuestions.Count > 0)
            {
                questions.AddRange(loadedQuestions);
                MessageBox.Show("Quiz loaded successfully.");
            }
            else
            {
                MessageBox.Show("No quiz questions loaded.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveQuiz_Click(object sender, RoutedEventArgs e)
        {
            //Check if there are questions to save
            if (questions.Count == 0)
            {
                MessageBox.Show("No questions to save.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Specify the file 
            string fileName = "quiz_questions.json"; 

            //Check if the file already exists
            if (File.Exists(fileName))
            {
                
                MessageBoxResult result = MessageBox.Show("A quiz file already exists. Do you want to overwrite it?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.No)
                {
                    return; //Don't proceed if the user chooses not to overwrite the file
                }
            }

            try
            {
                //Save quiz questions to a file
                QuizSerializer.SaveQuiz(fileName, questions);
                MessageBox.Show("Quiz saved successfully.");
            }
            catch (Exception ex)
            {
                //Handle exceptions 
                MessageBox.Show($"An error occurred while saving the quiz: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private List<Question> OpenQuizFromFile()
        {
            List<Question> loadedQuestions = null;

            //Create File
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Quiz files (*.quiz)|*.quiz|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    
                    string filePath = openFileDialog.FileName;
                    string json = File.ReadAllText(filePath);
                    loadedQuestions = QuizSerializer.LoadQuiz(json);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading quiz from file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            return loadedQuestions;
        }

        private void AddQuestion_Click(object sender, RoutedEventArgs e)
        {
            //add a new question
            var addQuestionWindow = new AddQuestionWindow(questions);
            addQuestionWindow.ShowDialog();
        }
    }
}
