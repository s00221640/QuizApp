﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace QuizApp
{
    public static class QuizSerializer
    {
        public static void SaveQuiz(string fileName, List<Question> questions)
        {
            string json = JsonConvert.SerializeObject(questions, Formatting.Indented);
            File.WriteAllText(fileName, json);
        }

        public static List<Question> LoadQuiz(string json)
        {
            return JsonConvert.DeserializeObject<List<Question>>(json);
        }
    }
}
