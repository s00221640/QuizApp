﻿using System.Collections.Generic;
using System.Windows;

namespace QuizApp
{
    public partial class AddQuestionWindow : Window
    {
        private List<Question> questions;

        public AddQuestionWindow(List<Question> questions)
        {
            InitializeComponent();
            this.questions = questions;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            // Get the input values
            string questionText = txtQuestionText.Text;
            string[] choices = txtChoices.Text.Split(',');
            int correctAnswerIndex;
            if (!int.TryParse(txtCorrectAnswerIndex.Text, out correctAnswerIndex))
            {
                MessageBox.Show("Please enter a valid index for the correct answer.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Create a new question object
            Question newQuestion = new Question(
                questions.Count + 1,
                questionText,
                choices,
                correctAnswerIndex,
                cmbSubject.SelectedItem.ToString(),
                null,
                null); // Assuming userAnswerIndex and imagePath are not required in this context

            // Add the new question to the list of questions
            questions.Add(newQuestion);

            // Close the window
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            // Close the window without adding a question
            Close();
        }
    }
}
