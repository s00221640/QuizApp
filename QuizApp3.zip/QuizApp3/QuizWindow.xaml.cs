﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace QuizApp
{
    public partial class QuizWindow : Window
    {
        private List<Question> questions;
        private int currentQuestionIndex = 0;
        private DispatcherTimer timer;
        private int totalTimeInSeconds = 120; //Total time for the quiz in seconds 

        public QuizWindow(List<Question> questions)
        {
            InitializeComponent();
            this.questions = questions;
            InitializeTimer();
            DisplayQuestion();
        }

        private void InitializeTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            totalTimeInSeconds--;

            if (totalTimeInSeconds <= 0)
            {
                timer.Stop();
                MessageBox.Show("Time's up! Quiz completed.");
                Close();
            }
            else
            {
                UpdateTimerUI();
            }
        }

        private void UpdateTimerUI()
        {
            int minutes = totalTimeInSeconds / 60;
            int seconds = totalTimeInSeconds % 60;
            lblTimer.Text = $"Time Remaining: {minutes:00}:{seconds:00}"; 
        }

        private void DisplayQuestion()
        {
            tblkQuestion.Text = questions[currentQuestionIndex].Text;
            lbxAnswers.ItemsSource = questions[currentQuestionIndex].Choices;
            lbxAnswers.SelectedIndex = questions[currentQuestionIndex].UserAnswerIndex ?? -1; // Set selected index based on UserAnswerIndex
            UpdateTimerUI();
        }

        private void NextQuestion_Click(object sender, RoutedEventArgs e)
        {
            questions[currentQuestionIndex].UserAnswerIndex = lbxAnswers.SelectedIndex;

            //Move to the next question
            currentQuestionIndex++;

            //Check if there are more questions
            if (currentQuestionIndex < questions.Count)
            {
                DisplayQuestion();
            }
            else
            {
                //Quiz completed
                int correctCount = 0;
                int totalQuestions = questions.Count;
                int pointsPerCorrectAnswer = 1; 

                StringBuilder resultMessage = new StringBuilder("Quiz completed!\n\n");

                foreach (var question in questions)
                {
                    resultMessage.Append($"Question {question.Id}: {question.Text}\n");

                    if (question.UserAnswerIndex.HasValue && question.UserAnswerIndex == question.CorrectAnswerIndex)
                    {
                        resultMessage.Append("Correct Answer!\n\n");
                        correctCount++;
                    }
                    else if (question.UserAnswerIndex.HasValue && question.UserAnswerIndex != question.CorrectAnswerIndex)
                    {
                        resultMessage.Append($"Incorrect. Correct Answer: {question.Choices[question.CorrectAnswerIndex]}\n\n");
                    }
                    else
                    {
                        resultMessage.Append("Not answered.\n\n");
                    }
                }

                //Calculate total score
                int totalScore = correctCount * pointsPerCorrectAnswer;

                //Display result message with score
                resultMessage.Append($"You got {correctCount} out of {totalQuestions} questions correct.\n");
                resultMessage.Append($"Total Score: {totalScore}");

                MessageBox.Show(resultMessage.ToString());

                Close(); //Close the quiz window
            }
        }

        private void lbxAnswers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Get index of selected answer
            int selectedIndex = lbxAnswers.SelectedIndex;

            //Check if the selected index is valid
            if (selectedIndex >= 0 && selectedIndex < questions[currentQuestionIndex].Choices.Length)
            {
                //Update Index property of question
                questions[currentQuestionIndex].UserAnswerIndex = selectedIndex;
            }
        }
    }
}
