﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace QuizApp
{
    public class Question
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string[] Choices { get; set; }
        public int CorrectAnswerIndex { get; set; }
        public string Subject { get; set; }
        public string ImagePath { get; set; }
        public int? UserAnswerIndex { get; set; }

        public Question(int id, string text, string[] choices, int correctAnswerIndex, string subject, string imagePath, int? userAnswerIndex)
        {
            Id = id;
            Text = text;
            Choices = choices;
            CorrectAnswerIndex = correctAnswerIndex;
            Subject = subject;
            ImagePath = imagePath;
            UserAnswerIndex = userAnswerIndex;
        }
    }
}
